# الإعمار الذكي — MVP PropTech Algérienne

Plateforme web SaaS de gestion, analyse et évaluation de projets immobiliers (Frontend only).

npm install
npm run dev

Build de production :
npm run build
